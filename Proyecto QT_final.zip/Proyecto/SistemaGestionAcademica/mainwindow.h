#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <vector>
#include <string>

using namespace std;

struct MateriaSemestre {
    string codigo, nombre;
    int creditos, horas;
    int semestre;
};

struct MateriaCursada {
    string codigo, nombre;
    int creditos;
    double nota;
    string periodo;
    string estado;
    int intentos;
    bool aprobada;
};

struct Estudiante {
    string cedula, nombre, carrera;
    int semestreActual;
    vector<MateriaCursada> materiasCursadas;
    double promedioAcumulado;
    int creditosAprobados;
    bool activo;
};

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onCrearEstudianteClicked();
    void onVerEstudiantesClicked();
    void onActualizarEstudianteClicked();
    void onEliminarEstudianteClicked();
    void onRegistrarNotaClicked();
    void onVerHistorialClicked();
    void onVerPendientesClicked();
    void onReporteEstadoClicked();
    void onReporteRendimientoClicked();
    void onGuardarArchivoClicked();
    void onCargarArchivoClicked();
    void onSalirSistemaClicked();
    void onTablaEstudiantesCellClicked(int row, int column);
    void onLimpiarFormularioClicked();
    void onExportarBoletaClicked();

    // Slots para menú principal
    void onMenuGestionEstudiantesClicked();
    void onMenuGestionAcademicaClicked();
    void onMenuConsultasReportesClicked();
    void onMenuArchivosClicked();
    void onMenuSalirClicked();

private:
    Ui::MainWindow *ui;
    vector<Estudiante> estudiantes;
    vector<MateriaSemestre> mallaCurricular;
    vector<string> periodos;
    int currentRowSelected;

    void setupConnections();
    void setupTable();
    void loadMallaCurricular();
    void actualizarTabla();
    void clearForm();

    Estudiante* buscarEstudiante(string cedula);
    MateriaSemestre* buscarMateriaMalla(string codigo);
    MateriaCursada* buscarMateriaCursada(Estudiante* estudiante, string codigo);
    vector<MateriaSemestre> obtenerMateriasSemestre(int semestre);
    bool cedulaValida(string cedula);

    void guardarEstudiantesTXT();
    void cargarEstudiantesTXT();
    void exportarBoletaEstudiante(string cedula);
};

#endif // MAINWINDOW_H
