QT += core gui widgets

CONFIG += c++11

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    loginwindow.cpp

HEADERS += \
    mainwindow.h \
    loginwindow.h

FORMS += \
    mainwindow.ui

TARGET = SistemaGestionAcademica
TEMPLATE = app

# Para Windows
win32 {
    CONFIG += console
}

# Configuración para evitar errores
greaterThan(QT_MAJOR_VERSION, 4): QT += widgets
CONFIG -= app_bundle
CONFIG -= qtquickcompiler
