#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QMessageBox>

class LoginWindow : public QDialog
{
    Q_OBJECT

public:
    LoginWindow(QWidget *parent = nullptr);
    ~LoginWindow();

private slots:
    void onLoginClicked();
    void onCancelClicked();

private:
    QLabel *labelUsuario;
    QLabel *labelClave;
    QLineEdit *lineEditUsuario;
    QLineEdit *lineEditClave;
    QPushButton *btnLogin;
    QPushButton *btnCancel;
};

#endif // LOGINWINDOW_H
