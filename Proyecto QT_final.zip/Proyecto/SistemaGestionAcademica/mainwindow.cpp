#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QFileDialog>
#include <QTextStream>
#include <QFile>
#include <QHeaderView>
#include <QDateTime>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , currentRowSelected(-1)
{
    ui->setupUi(this);

    // Configurar interfaz
    setWindowTitle("Sistema de Gestión Académica - Desarrollo de Software");

    // Configurar tabla
    setupTable();

    // Cargar datos
    loadMallaCurricular();

    // Conectar señales
    setupConnections();

    // Cargar estudiantes si existen
    cargarEstudiantesTXT();

    // Actualizar tabla inicial
    actualizarTabla();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupConnections()
{
    // Botones del formulario
    connect(ui->btnGuardar, &QPushButton::clicked, this, &MainWindow::onCrearEstudianteClicked);
    connect(ui->btnActualizar, &QPushButton::clicked, this, &MainWindow::onActualizarEstudianteClicked);
    connect(ui->btnEliminar, &QPushButton::clicked, this, &MainWindow::onEliminarEstudianteClicked);
    connect(ui->btnLimpiar, &QPushButton::clicked, this, &MainWindow::onLimpiarFormularioClicked);
    connect(ui->btnExportarBoleta, &QPushButton::clicked, this, &MainWindow::onExportarBoletaClicked);

    // Botones del menú derecho (funciones específicas)
    connect(ui->btnCrearEstudiante, &QPushButton::clicked, this, &MainWindow::onCrearEstudianteClicked);
    connect(ui->btnVerEstudiantes, &QPushButton::clicked, this, &MainWindow::onVerEstudiantesClicked);
    connect(ui->btnActualizarEst, &QPushButton::clicked, this, &MainWindow::onActualizarEstudianteClicked);
    connect(ui->btnEliminarEst, &QPushButton::clicked, this, &MainWindow::onEliminarEstudianteClicked);
    connect(ui->btnRegistrarNota, &QPushButton::clicked, this, &MainWindow::onRegistrarNotaClicked);
    connect(ui->btnVerHistorial, &QPushButton::clicked, this, &MainWindow::onVerHistorialClicked);
    connect(ui->btnVerPendientes, &QPushButton::clicked, this, &MainWindow::onVerPendientesClicked);
    connect(ui->btnReporteEstado, &QPushButton::clicked, this, &MainWindow::onReporteEstadoClicked);
    connect(ui->btnReporteRendimiento, &QPushButton::clicked, this, &MainWindow::onReporteRendimientoClicked);
    connect(ui->btnGuardarArchivo, &QPushButton::clicked, this, &MainWindow::onGuardarArchivoClicked);
    connect(ui->btnCargarArchivo, &QPushButton::clicked, this, &MainWindow::onCargarArchivoClicked);
    connect(ui->btnSalirSistema, &QPushButton::clicked, this, &MainWindow::onSalirSistemaClicked);

    // Botones del menú principal
    connect(ui->btnMenuGestionEstudiantes, &QPushButton::clicked, this, &MainWindow::onMenuGestionEstudiantesClicked);
    connect(ui->btnMenuGestionAcademica, &QPushButton::clicked, this, &MainWindow::onMenuGestionAcademicaClicked);
    connect(ui->btnMenuConsultasReportes, &QPushButton::clicked, this, &MainWindow::onMenuConsultasReportesClicked);
    connect(ui->btnMenuArchivos, &QPushButton::clicked, this, &MainWindow::onMenuArchivosClicked);
    connect(ui->btnMenuSalir, &QPushButton::clicked, this, &MainWindow::onMenuSalirClicked);

    // Tabla
    connect(ui->tableWidgetEstudiantes, &QTableWidget::cellClicked, this, &MainWindow::onTablaEstudiantesCellClicked);
}

void MainWindow::setupTable()
{
    ui->tableWidgetEstudiantes->setColumnCount(6);
    QStringList headers = {"Cédula", "Nombre", "Semestre", "Promedio", "Créditos", "Estado"};
    ui->tableWidgetEstudiantes->setHorizontalHeaderLabels(headers);
    ui->tableWidgetEstudiantes->horizontalHeader()->setStretchLastSection(true);
    ui->tableWidgetEstudiantes->setAlternatingRowColors(true);
}

void MainWindow::loadMallaCurricular()
{
    mallaCurricular = {
        // Semestre 1
        {"CSHD111", "Comunicación Oral y Escrita", 1, 48, 1},
        {"MATD143", "Cálculo Diferencial e Integral", 3, 144, 1},
        {"ICOD142", "Introducción a las TICS", 2, 96, 1},
        {"FISD113", "Física", 3, 144, 1},
        {"MATD153", "Estadística y Probabilidad Básica", 3, 144, 1},
        {"ADMD163", "Administración Financiera", 3, 144, 1},

        // Semestre 2
        {"TDSD214", "Programación", 4, 192, 2},
        {"TDSD222", "Algoritmos y Estructuras de Datos", 2, 96, 2},
        {"TDSD232", "Arquitectura de Computadores", 2, 96, 2},
        {"TDSD243", "Redes de Computadores", 3, 144, 2},
        {"AMBD261", "Ecología y Ambiente", 1, 48, 2},
        {"TDSD253", "Sistemas Operativos", 3, 144, 2},

        // Semestre 3
        {"TDSD314", "Programación Orientada a Objetos", 4, 192, 3},
        {"TDSD343", "Bases de Datos", 3, 144, 3},
        {"TDSD322", "Diseño de Interfaces", 2, 96, 3},
        {"TDSD333", "Gestión de Proyectos de Software", 3, 144, 3},
        {"TDSD353", "Análisis de Datos", 3, 144, 3},

        // Semestre 4
        {"TDSD422", "Desarrollo de IoT", 2, 96, 4},
        {"TDSD431", "Fundamentos de Inteligencia Artificial", 1, 48, 4},
        {"ADMD421", "Metodología de la Investigación", 1, 48, 4},
        {"TDSD414", "Desarrollo de Aplicaciones Web", 4, 192, 4},

        // Semestre 5
        {"TDSD514", "Desarrollo de Aplicaciones Móviles", 4, 192, 5},
        {"TDSD523", "Aplicaciones Distribuidas", 3, 144, 5},
        {"TDSD532", "Tecnologías de Seguridad", 2, 96, 5},
        {"PSCD202", "Prácticas de Servicio Comunitario", 2, 96, 5},
        {"PRLD105", "Prácticas Laborales", 5, 240, 5},
        {"TITD103", "Diseño de Trabajo de Integración Curricular", 3, 144, 5},
        {"TITD201", "Trabajo de Integración Curricular/Examen Complexivo", 5, 240, 5}
    };

    // Cargar materias en combobox
    ui->comboBoxMateria->clear();
    ui->comboBoxMateria->addItem("Seleccione una materia");
    for (const auto& materia : mallaCurricular) {
        QString item = QString::fromStdString(materia.codigo + " - " + materia.nombre);
        ui->comboBoxMateria->addItem(item);
    }

    // Cargar periodos
    periodos = {"2024-A", "2024-B", "2025-A", "2025-B", "2026-A", "2026-B"};
    ui->comboBoxPeriodo->clear();
    for (const auto& periodo : periodos) {
        ui->comboBoxPeriodo->addItem(QString::fromStdString(periodo));
    }
}

void MainWindow::actualizarTabla()
{
    if (!ui->tableWidgetEstudiantes) {
        qDebug() << "Error: tableWidgetEstudiantes no existe";
        return;
    }

    ui->tableWidgetEstudiantes->setRowCount(estudiantes.size());

    for (size_t i = 0; i < estudiantes.size(); i++) {
        const Estudiante& est = estudiantes[i];

        ui->tableWidgetEstudiantes->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(est.cedula)));
        ui->tableWidgetEstudiantes->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(est.nombre)));
        ui->tableWidgetEstudiantes->setItem(i, 2, new QTableWidgetItem(QString::number(est.semestreActual)));
        ui->tableWidgetEstudiantes->setItem(i, 3, new QTableWidgetItem(QString::number(est.promedioAcumulado, 'f', 2)));
        ui->tableWidgetEstudiantes->setItem(i, 4, new QTableWidgetItem(QString::number(est.creditosAprobados)));
        ui->tableWidgetEstudiantes->setItem(i, 5, new QTableWidgetItem(est.activo ? "ACTIVO" : "INACTIVO"));
    }

    ui->tableWidgetEstudiantes->resizeColumnsToContents();
}

void MainWindow::clearForm()
{
    ui->lineEditCedula->clear();
    ui->lineEditNombre->clear();
    ui->spinBoxSemestre->setValue(1);
    ui->doubleSpinBoxNota->setValue(0.0);
    ui->comboBoxMateria->setCurrentIndex(0);
    ui->comboBoxPeriodo->setCurrentIndex(0);
    currentRowSelected = -1;
}

bool MainWindow::cedulaValida(string cedula)
{
    if (cedula.length() != 10) {
        QMessageBox::warning(this, "Error", "La cédula debe tener 10 dígitos");
        return false;
    }

    for (int i = 0; i < 10; i++) {
        if (cedula[i] < '0' || cedula[i] > '9') {
            QMessageBox::warning(this, "Error", "La cédula solo debe contener números");
            return false;
        }
    }

    int provincia = (cedula[0] - '0') * 10 + (cedula[1] - '0');
    if (!((provincia >= 1 && provincia <= 24) || provincia == 30)) {
        QMessageBox::warning(this, "Error", "Código de provincia inválido");
        return false;
    }

    return true;
}

Estudiante* MainWindow::buscarEstudiante(string cedula)
{
    for (auto& estudiante : estudiantes) {
        if (estudiante.cedula == cedula) {
            return &estudiante;
        }
    }
    return nullptr;
}

MateriaSemestre* MainWindow::buscarMateriaMalla(string codigo)
{
    for (auto& materia : mallaCurricular) {
        if (materia.codigo == codigo) {
            return &materia;
        }
    }
    return nullptr;
}

MateriaCursada* MainWindow::buscarMateriaCursada(Estudiante* estudiante, string codigo)
{
    for (auto& materia : estudiante->materiasCursadas) {
        if (materia.codigo == codigo) {
            return &materia;
        }
    }
    return nullptr;
}

vector<MateriaSemestre> MainWindow::obtenerMateriasSemestre(int semestre)
{
    vector<MateriaSemestre> materiasSemestre;
    for (const auto& materia : mallaCurricular) {
        if (materia.semestre == semestre) {
            materiasSemestre.push_back(materia);
        }
    }
    return materiasSemestre;
}

// ============== SLOTS PRINCIPALES ==============

void MainWindow::onCrearEstudianteClicked()
{
    string cedula = ui->lineEditCedula->text().toStdString();
    string nombre = ui->lineEditNombre->text().toStdString();
    int semestre = ui->spinBoxSemestre->value();

    if (!cedulaValida(cedula)) return;

    if (nombre.empty()) {
        QMessageBox::warning(this, "Error", "El nombre no puede estar vacío");
        return;
    }

    if (buscarEstudiante(cedula) != nullptr) {
        QMessageBox::warning(this, "Error", "Ya existe un estudiante con esta cédula");
        return;
    }

    Estudiante nuevo;
    nuevo.cedula = cedula;
    nuevo.nombre = nombre;
    nuevo.carrera = "Desarrollo de Software";
    nuevo.semestreActual = semestre;
    nuevo.promedioAcumulado = 0.0;
    nuevo.creditosAprobados = 0;
    nuevo.activo = true;

    estudiantes.push_back(nuevo);

    QMessageBox::information(this, "Éxito", "Estudiante creado exitosamente");
    actualizarTabla();
    clearForm();
}

void MainWindow::onVerEstudiantesClicked()
{
    actualizarTabla();
}

void MainWindow::onActualizarEstudianteClicked()
{
    if (currentRowSelected < 0 || currentRowSelected >= (int)estudiantes.size()) {
        QMessageBox::warning(this, "Error", "Seleccione un estudiante de la tabla primero");
        return;
    }

    Estudiante& estudiante = estudiantes[currentRowSelected];

    // Actualizar datos básicos
    estudiante.nombre = ui->lineEditNombre->text().toStdString();
    estudiante.semestreActual = ui->spinBoxSemestre->value();

    QMessageBox::information(this, "Éxito", "Estudiante actualizado correctamente");
    actualizarTabla();
}

void MainWindow::onEliminarEstudianteClicked()
{
    if (currentRowSelected < 0 || currentRowSelected >= (int)estudiantes.size()) {
        QMessageBox::warning(this, "Error", "Seleccione un estudiante de la tabla primero");
        return;
    }

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirmar eliminación",
                                  "¿Está seguro de eliminar este estudiante?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        estudiantes.erase(estudiantes.begin() + currentRowSelected);
        QMessageBox::information(this, "Éxito", "Estudiante eliminado exitosamente");
        actualizarTabla();
        clearForm();
    }
}

void MainWindow::onTablaEstudiantesCellClicked(int row, int column)
{
    Q_UNUSED(column);

    if (row < 0 || row >= (int)estudiantes.size()) return;

    currentRowSelected = row;
    const Estudiante& estudiante = estudiantes[row];

    ui->lineEditCedula->setText(QString::fromStdString(estudiante.cedula));
    ui->lineEditNombre->setText(QString::fromStdString(estudiante.nombre));
    ui->spinBoxSemestre->setValue(estudiante.semestreActual);
}

void MainWindow::onLimpiarFormularioClicked()
{
    clearForm();
}

void MainWindow::onExportarBoletaClicked()
{
    if (currentRowSelected < 0 || currentRowSelected >= (int)estudiantes.size()) {
        QMessageBox::warning(this, "Error", "Seleccione un estudiante de la tabla primero");
        return;
    }

    string cedula = estudiantes[currentRowSelected].cedula;
    exportarBoletaEstudiante(cedula);
}

void MainWindow::onSalirSistemaClicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Salir",
                                  "¿Desea guardar los cambios antes de salir?",
                                  QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);

    if (reply == QMessageBox::Yes) {
        guardarEstudiantesTXT();
        qApp->quit();
    } else if (reply == QMessageBox::No) {
        qApp->quit();
    }
}

// ============== SLOTS DE FUNCIONALIDADES ESPECÍFICAS ==============

void MainWindow::onRegistrarNotaClicked()
{
    if (currentRowSelected < 0 || currentRowSelected >= (int)estudiantes.size()) {
        QMessageBox::warning(this, "Error", "Seleccione un estudiante de la tabla primero");
        return;
    }

    QString materiaStr = ui->comboBoxMateria->currentText();
    double nota = ui->doubleSpinBoxNota->value();
    QString periodo = ui->comboBoxPeriodo->currentText();

    if (materiaStr == "Seleccione una materia" || materiaStr.isEmpty()) {
        QMessageBox::warning(this, "Error", "Seleccione una materia");
        return;
    }

    if (nota < 0.0 || nota > 10.0) {
        QMessageBox::warning(this, "Error", "La nota debe estar entre 0.0 y 10.0");
        return;
    }

    // Extraer código de materia
    QStringList partes = materiaStr.split(" - ");
    if (partes.size() < 2) {
        QMessageBox::warning(this, "Error", "Formato de materia inválido");
        return;
    }

    string codigo = partes[0].toStdString();
    string nombreMateria = partes[1].toStdString();

    Estudiante& estudiante = estudiantes[currentRowSelected];

    // Buscar si ya tiene esta materia
    MateriaCursada* materiaExistente = buscarMateriaCursada(&estudiante, codigo);
    MateriaSemestre* materiaMalla = buscarMateriaMalla(codigo);

    if (!materiaMalla) {
        QMessageBox::warning(this, "Error", "Materia no encontrada en la malla curricular");
        return;
    }

    if (materiaExistente && materiaExistente->aprobada) {
        QMessageBox::warning(this, "Error", "El estudiante ya aprobó esta materia");
        return;
    }

    if (materiaExistente && materiaExistente->intentos >= 3) {
        QMessageBox::warning(this, "Error", "El estudiante agotó los 3 intentos para esta materia");
        return;
    }

    string estado = (nota >= 7.0) ? "Aprobado" : "Reprobado";
    bool aprobada = (nota >= 7.0);

    if (materiaExistente) {
        // Actualizar materia existente
        materiaExistente->nota = nota;
        materiaExistente->estado = estado;
        materiaExistente->aprobada = aprobada;
        materiaExistente->periodo = periodo.toStdString();
        materiaExistente->intentos++;
    } else {
        // Crear nueva materia cursada
        MateriaCursada nuevaMateria;
        nuevaMateria.codigo = codigo;
        nuevaMateria.nombre = nombreMateria;
        nuevaMateria.creditos = materiaMalla->creditos;
        nuevaMateria.nota = nota;
        nuevaMateria.periodo = periodo.toStdString();
        nuevaMateria.estado = estado;
        nuevaMateria.intentos = 1;
        nuevaMateria.aprobada = aprobada;

        estudiante.materiasCursadas.push_back(nuevaMateria);
    }

    // Recalcular promedio y créditos
    if (aprobada) {
        estudiante.creditosAprobados += materiaMalla->creditos;

        double sumaNotas = 0.0;
        int totalCreditos = 0;

        for (const auto& materia : estudiante.materiasCursadas) {
            if (materia.aprobada) {
                sumaNotas += materia.nota * materia.creditos;
                totalCreditos += materia.creditos;
            }
        }

        if (totalCreditos > 0) {
            estudiante.promedioAcumulado = sumaNotas / totalCreditos;
        }
    }

    QMessageBox::information(this, "Éxito", "Nota registrada exitosamente");
    actualizarTabla();
}

void MainWindow::onVerHistorialClicked()
{
    if (currentRowSelected < 0 || currentRowSelected >= (int)estudiantes.size()) {
        QMessageBox::warning(this, "Error", "Seleccione un estudiante de la tabla primero");
        return;
    }

    Estudiante& estudiante = estudiantes[currentRowSelected];

    QString historial = "=== HISTORIAL ACADÉMICO ===\n";
    historial += "Estudiante: " + QString::fromStdString(estudiante.nombre) + "\n";
    historial += "Cédula: " + QString::fromStdString(estudiante.cedula) + "\n";
    historial += "Promedio: " + QString::number(estudiante.promedioAcumulado, 'f', 2) + "\n";
    historial += "Créditos aprobados: " + QString::number(estudiante.creditosAprobados) + "/75\n\n";

    if (estudiante.materiasCursadas.empty()) {
        historial += "No hay materias cursadas registradas.\n";
    } else {
        historial += "Materias cursadas:\n";
        historial += "----------------------------------------\n";
        for (const auto& materia : estudiante.materiasCursadas) {
            historial += QString::fromStdString(materia.codigo) + " - " +
                         QString::fromStdString(materia.nombre) + "\n";
            historial += "  Nota: " + QString::number(materia.nota, 'f', 1) +
                         "  Estado: " + QString::fromStdString(materia.estado) +
                         "  Intentos: " + QString::number(materia.intentos) +
                         "  Período: " + QString::fromStdString(materia.periodo) + "\n";
        }
    }

    QMessageBox::information(this, "Historial Académico", historial);
}

void MainWindow::onVerPendientesClicked()
{
    if (currentRowSelected < 0 || currentRowSelected >= (int)estudiantes.size()) {
        QMessageBox::warning(this, "Error", "Seleccione un estudiante de la tabla primero");
        return;
    }

    Estudiante& estudiante = estudiantes[currentRowSelected];

    QString pendientes = "=== MATERIAS PENDIENTES ===\n";
    pendientes += "Estudiante: " + QString::fromStdString(estudiante.nombre) + "\n";
    pendientes += "Semestre actual: " + QString::number(estudiante.semestreActual) + "\n\n";

    for (int semestre = 1; semestre <= estudiante.semestreActual; semestre++) {
        vector<MateriaSemestre> materiasSemestre = obtenerMateriasSemestre(semestre);

        pendientes += "Semestre " + QString::number(semestre) + ":\n";

        bool tienePendientes = false;
        for (const auto& materia : materiasSemestre) {
            bool aprobada = false;

            for (const auto& materiaCursada : estudiante.materiasCursadas) {
                if (materiaCursada.codigo == materia.codigo && materiaCursada.aprobada) {
                    aprobada = true;
                    break;
                }
            }

            if (!aprobada) {
                tienePendientes = true;
                pendientes += "  " + QString::fromStdString(materia.codigo) + " - " +
                              QString::fromStdString(materia.nombre) +
                              " (" + QString::number(materia.creditos) + " créditos)\n";
            }
        }

        if (!tienePendientes) {
            pendientes += "  Todas las materias aprobadas ✓\n";
        }
        pendientes += "\n";
    }

    QMessageBox::information(this, "Materias Pendientes", pendientes);
}

void MainWindow::onReporteEstadoClicked()
{
    if (estudiantes.empty()) {
        QMessageBox::information(this, "Reporte", "No hay estudiantes registrados");
        return;
    }

    int activos = 0, inactivos = 0;

    for (const auto& estudiante : estudiantes) {
        if (estudiante.activo) activos++;
        else inactivos++;
    }

    QString reporte = "=== REPORTE POR ESTADO ===\n";
    reporte += "Total estudiantes: " + QString::number(estudiantes.size()) + "\n";
    reporte += "Estudiantes activos: " + QString::number(activos) +
               " (" + QString::number((activos * 100.0) / estudiantes.size(), 'f', 1) + "%)\n";
    reporte += "Estudiantes inactivos: " + QString::number(inactivos) +
               " (" + QString::number((inactivos * 100.0) / estudiantes.size(), 'f', 1) + "%)\n";

    QMessageBox::information(this, "Reporte por Estado", reporte);
}

void MainWindow::onReporteRendimientoClicked()
{
    if (estudiantes.empty()) {
        QMessageBox::information(this, "Reporte", "No hay estudiantes registrados");
        return;
    }

    int excelentes = 0, buenos = 0, regulares = 0, deficientes = 0, sinNotas = 0;
    double promedioGeneral = 0.0;
    int estudiantesConNotas = 0;

    for (const auto& estudiante : estudiantes) {
        if (estudiante.creditosAprobados > 0) {
            estudiantesConNotas++;
            promedioGeneral += estudiante.promedioAcumulado;

            if (estudiante.promedioAcumulado >= 9.0) excelentes++;
            else if (estudiante.promedioAcumulado >= 7.0) buenos++;
            else if (estudiante.promedioAcumulado >= 5.0) regulares++;
            else deficientes++;
        } else {
            sinNotas++;
        }
    }

    if (estudiantesConNotas > 0) {
        promedioGeneral /= estudiantesConNotas;
    }

    QString reporte = "=== REPORTE DE RENDIMIENTO ===\n";
    reporte += "Total estudiantes: " + QString::number(estudiantes.size()) + "\n";
    reporte += "Promedio general: " + QString::number(promedioGeneral, 'f', 2) + "\n\n";
    reporte += "Distribución:\n";
    reporte += "Excelente (>=9.0): " + QString::number(excelentes) + "\n";
    reporte += "Bueno (7.0-8.9): " + QString::number(buenos) + "\n";
    reporte += "Regular (5.0-6.9): " + QString::number(regulares) + "\n";
    reporte += "Deficiente (<5.0): " + QString::number(deficientes) + "\n";
    reporte += "Sin notas: " + QString::number(sinNotas) + "\n";

    QMessageBox::information(this, "Reporte de Rendimiento", reporte);
}

void MainWindow::onGuardarArchivoClicked()
{
    guardarEstudiantesTXT();
}

void MainWindow::onCargarArchivoClicked()
{
    cargarEstudiantesTXT();
    actualizarTabla();
    QMessageBox::information(this, "Cargar", "Estudiantes cargados exitosamente");
}

// ============== SLOTS DEL MENÚ PRINCIPAL ==============

void MainWindow::onMenuGestionEstudiantesClicked()
{
    QMessageBox::information(this, "Gestión de Estudiantes",
                             "Seleccione una opción del submenú 'Gestión de Estudiantes'");
}

void MainWindow::onMenuGestionAcademicaClicked()
{
    QMessageBox::information(this, "Gestión Académica",
                             "Seleccione una opción del submenú 'Gestión Académica'");
}

void MainWindow::onMenuConsultasReportesClicked()
{
    QMessageBox::information(this, "Consultas y Reportes",
                             "Seleccione una opción del submenú 'Consultas y Reportes'");
}

void MainWindow::onMenuArchivosClicked()
{
    QMessageBox::information(this, "Archivos",
                             "Seleccione una opción del submenú 'Archivos'");
}

void MainWindow::onMenuSalirClicked()
{
    onSalirSistemaClicked();
}

// ============== FUNCIONES DE ARCHIVOS ==============

void MainWindow::guardarEstudiantesTXT()
{
    QString fileName = QFileDialog::getSaveFileName(this,
                                                    "Guardar estudiantes", "C:\\Users\\Patricio\\Downloads\\Proyecto\\estudiantes.txt",
                                                    "Archivos de texto (*.txt);;Todos los archivos (*)");

    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "No se pudo abrir el archivo para escribir");
        return;
    }

    QTextStream out(&file);

    out << "=== SISTEMA DE GESTIÓN ACADÉMICA ===\n";
    out << "Fecha: " << QDateTime::currentDateTime().toString("dd/MM/yyyy hh:mm:ss") << "\n";
    out << "Total estudiantes: " << estudiantes.size() << "\n\n";

    for (const auto& estudiante : estudiantes) {
        out << "Cédula: " << QString::fromStdString(estudiante.cedula) << "\n";
        out << "Nombre: " << QString::fromStdString(estudiante.nombre) << "\n";
        out << "Carrera: " << QString::fromStdString(estudiante.carrera) << "\n";
        out << "Semestre: " << estudiante.semestreActual << "\n";
        out << "Promedio: " << QString::number(estudiante.promedioAcumulado, 'f', 2) << "\n";
        out << "Créditos aprobados: " << estudiante.creditosAprobados << "/75\n";
        out << "Estado: " << (estudiante.activo ? "ACTIVO" : "INACTIVO") << "\n";

        if (!estudiante.materiasCursadas.empty()) {
            out << "Materias cursadas:\n";
            for (const auto& materia : estudiante.materiasCursadas) {
                out << "  " << QString::fromStdString(materia.codigo) << " - "
                    << QString::fromStdString(materia.nombre) << ": "
                    << materia.nota << " (" << QString::fromStdString(materia.estado)
                    << ") - " << QString::fromStdString(materia.periodo) << "\n";
            }
        }
        out << "----------------------------------------\n";
    }

    file.close();
    QMessageBox::information(this, "Éxito", "Datos guardados en: " + fileName);
}

void MainWindow::cargarEstudiantesTXT()
{
    QString fileName = "C:\\Users\\Patricio\\Downloads\\Proyecto\\estudiantes.txt";

    QFile file(fileName);
    if (!file.exists()) {
        return; // Archivo no existe
    }

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "No se pudo abrir el archivo para leer");
        return;
    }

    QTextStream in(&file);
    estudiantes.clear();

    Estudiante estudianteActual;
    bool leyendoMaterias = false;

    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();

        if (line.isEmpty()) continue;

        if (line.startsWith("Cédula:")) {
            if (!estudianteActual.cedula.empty()) {
                estudiantes.push_back(estudianteActual);
                estudianteActual = Estudiante();
            }
            estudianteActual.cedula = line.mid(8).toStdString();
            leyendoMaterias = false;
        }
        else if (line.startsWith("Nombre:")) {
            estudianteActual.nombre = line.mid(8).toStdString();
        }
        else if (line.startsWith("Carrera:")) {
            estudianteActual.carrera = line.mid(9).toStdString();
        }
        else if (line.startsWith("Semestre:")) {
            estudianteActual.semestreActual = line.mid(10).toInt();
        }
        else if (line.startsWith("Promedio:")) {
            estudianteActual.promedioAcumulado = line.mid(10).toDouble();
        }
        else if (line.startsWith("Créditos aprobados:")) {
            QString creditos = line.mid(20).split("/")[0];
            estudianteActual.creditosAprobados = creditos.toInt();
        }
        else if (line.startsWith("Estado:")) {
            estudianteActual.activo = (line.mid(8) == "ACTIVO");
        }
        else if (line.startsWith("Materias cursadas:")) {
            leyendoMaterias = true;
        }
        else if (line.startsWith("  ") && leyendoMaterias) {
            // Procesar materia cursada
            QStringList partes = line.trimmed().split(":");
            if (partes.size() >= 2) {
                QStringList infoMateria = partes[0].split(" - ");
                if (infoMateria.size() >= 2) {
                    MateriaCursada materia;
                    materia.codigo = infoMateria[0].trimmed().toStdString();
                    materia.nombre = infoMateria[1].trimmed().toStdString();

                    // Extraer nota, estado y periodo
                    QString detalles = partes[1].trimmed();
                    QStringList detallePartes = detalles.split(" ");
                    if (detallePartes.size() >= 3) {
                        materia.nota = detallePartes[0].toDouble();
                        materia.estado = detallePartes[1].mid(1).toStdString(); // Quitar paréntesis
                        materia.periodo = detallePartes.last().toStdString();
                        materia.intentos = 1;
                        materia.aprobada = (materia.estado == "Aprobado");

                        // Buscar créditos en la malla
                        MateriaSemestre* materiaMalla = buscarMateriaMalla(materia.codigo);
                        if (materiaMalla) {
                            materia.creditos = materiaMalla->creditos;
                        }

                        estudianteActual.materiasCursadas.push_back(materia);
                    }
                }
            }
        }
        else if (line.startsWith("---")) {
            leyendoMaterias = false;
        }
    }

    // Agregar el último estudiante
    if (!estudianteActual.cedula.empty()) {
        estudiantes.push_back(estudianteActual);
    }

    file.close();
}

void MainWindow::exportarBoletaEstudiante(string cedula)
{
    Estudiante* estudiante = buscarEstudiante(cedula);
    if (!estudiante) {
        QMessageBox::warning(this, "Error", "Estudiante no encontrado");
        return;
    }

    QString fileName = QFileDialog::getSaveFileName(this,
                                                    "Exportar boleta",
                                                    "C:\\Users\\Patricio\\Downloads\\Proyecto\\boleta_" + QString::fromStdString(cedula) + ".txt",
                                                    "Archivos de texto (*.txt);;Todos los archivos (*)");

    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "No se pudo crear el archivo");
        return;
    }

    QTextStream out(&file);

    out << "==================================================\n";
    out << "            BOLETA DE CALIFICACIONES\n";
    out << "     SISTEMA DE GESTIÓN ACADÉMICA\n";
    out << "==================================================\n\n";

    out << "DATOS DEL ESTUDIANTE:\n";
    out << "--------------------------------------------------\n";
    out << "Nombre:      " << QString::fromStdString(estudiante->nombre) << "\n";
    out << "Cédula:      " << QString::fromStdString(estudiante->cedula) << "\n";
    out << "Carrera:     " << QString::fromStdString(estudiante->carrera) << "\n";
    out << "Semestre:    " << estudiante->semestreActual << "\n";
    out << "Promedio:    " << QString::number(estudiante->promedioAcumulado, 'f', 2) << "\n";
    out << "Créditos:    " << estudiante->creditosAprobados << "/75\n";
    out << "Estado:      " << (estudiante->activo ? "ACTIVO" : "INACTIVO") << "\n\n";

    out << "HISTORIAL ACADÉMICO:\n";
    out << "--------------------------------------------------\n";

    if (estudiante->materiasCursadas.empty()) {
        out << "No hay materias cursadas registradas.\n";
    } else {
        for (const auto& materia : estudiante->materiasCursadas) {
            out << QString::fromStdString(materia.codigo) << " - "
                << QString::fromStdString(materia.nombre) << "\n";
            out << "  Nota: " << QString::number(materia.nota, 'f', 1)
                << "  Estado: " << QString::fromStdString(materia.estado)
                << "  Intentos: " << materia.intentos
                << "  Período: " << QString::fromStdString(materia.periodo)
                << "  Créditos: " << materia.creditos << "\n";
        }
    }

    out << "\n==================================================\n";
    out << "Fecha de emisión: " << QDateTime::currentDateTime().toString("dd/MM/yyyy hh:mm:ss") << "\n";
    out << "==================================================\n";

    file.close();
    QMessageBox::information(this, "Éxito", "Boleta exportada: " + fileName);
}
