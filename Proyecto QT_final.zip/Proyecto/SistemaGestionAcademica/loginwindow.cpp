#include "loginwindow.h"
#include <QApplication>

LoginWindow::LoginWindow(QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle("Sistema de Gestión Académica - Login");
    setFixedSize(400, 250);

    // Configurar colores según imagen
    QPalette pal = palette();
    pal.setColor(QPalette::Window, QColor(240, 248, 255)); // Azul claro
    pal.setColor(QPalette::WindowText, QColor(0, 51, 102)); // Azul oscuro
    setPalette(pal);

    // Widgets
    QLabel *labelTitulo = new QLabel("=== SISTEMA DE GESTIÓN ACADÉMICA ===");
    labelTitulo->setAlignment(Qt::AlignCenter);
    labelTitulo->setStyleSheet("font-weight: bold; font-size: 16px; color: #003366;");

    QLabel *labelLogin = new QLabel("=== LOGIN ===");
    labelLogin->setAlignment(Qt::AlignCenter);
    labelLogin->setStyleSheet("font-weight: bold; font-size: 14px; color: #0066CC;");

    labelUsuario = new QLabel("Usuario:");
    labelUsuario->setStyleSheet("color: #003366;");

    labelClave = new QLabel("Clave:");
    labelClave->setStyleSheet("color: #003366;");

    lineEditUsuario = new QLineEdit();
    lineEditUsuario->setPlaceholderText("Ingrese usuario");
    lineEditUsuario->setStyleSheet("padding: 5px; border: 1px solid #0066CC; border-radius: 3px;");

    lineEditClave = new QLineEdit();
    lineEditClave->setPlaceholderText("Ingrese clave");
    lineEditClave->setEchoMode(QLineEdit::Password);
    lineEditClave->setStyleSheet("padding: 5px; border: 1px solid #0066CC; border-radius: 3px;");

    // Botones
    btnLogin = new QPushButton("Login");
    btnLogin->setStyleSheet(
        "QPushButton {"
        "background-color: #4CAF50;"
        "color: white;"
        "padding: 10px 20px;"
        "border: none;"
        "border-radius: 5px;"
        "font-weight: bold;"
        "}"
        "QPushButton:hover {"
        "background-color: #45a049;"
        "}"
        );

    btnCancel = new QPushButton("Cancelar");
    btnCancel->setStyleSheet(
        "QPushButton {"
        "background-color: #f44336;"
        "color: white;"
        "padding: 10px 20px;"
        "border: none;"
        "border-radius: 5px;"
        "font-weight: bold;"
        "}"
        "QPushButton:hover {"
        "background-color: #da190b;"
        "}"
        );

    // Layout
    QVBoxLayout *mainLayout = new QVBoxLayout();
    mainLayout->addWidget(labelTitulo);
    mainLayout->addWidget(labelLogin);
    mainLayout->addSpacing(20);

    QHBoxLayout *userLayout = new QHBoxLayout();
    userLayout->addWidget(labelUsuario);
    userLayout->addWidget(lineEditUsuario);
    mainLayout->addLayout(userLayout);

    QHBoxLayout *passLayout = new QHBoxLayout();
    passLayout->addWidget(labelClave);
    passLayout->addWidget(lineEditClave);
    mainLayout->addLayout(passLayout);

    mainLayout->addSpacing(20);

    QHBoxLayout *buttonLayout = new QHBoxLayout();
    buttonLayout->addWidget(btnLogin);
    buttonLayout->addWidget(btnCancel);
    mainLayout->addLayout(buttonLayout);

    setLayout(mainLayout);

    // Conexiones
    connect(btnLogin, &QPushButton::clicked, this, &LoginWindow::onLoginClicked);
    connect(btnCancel, &QPushButton::clicked, this, &LoginWindow::onCancelClicked);
    connect(lineEditClave, &QLineEdit::returnPressed, this, &LoginWindow::onLoginClicked);
}

LoginWindow::~LoginWindow() {}

void LoginWindow::onLoginClicked()
{
    QString usuario = lineEditUsuario->text();
    QString clave = lineEditClave->text();

    if (usuario == "admin" && clave == "1234") {
        QMessageBox::information(this, "Login Exitoso", "¡Bienvenido al Sistema de Gestión Académica!");
        accept();
    } else {
        QMessageBox::warning(this, "Error de Login", "Usuario o clave incorrectos.\nIntente nuevamente.");
        lineEditClave->clear();
        lineEditClave->setFocus();
    }
}

void LoginWindow::onCancelClicked()
{
    reject();
}
